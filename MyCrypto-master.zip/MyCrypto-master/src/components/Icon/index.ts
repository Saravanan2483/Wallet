export { default, TIcon, getSVGIcon } from './Icon';
