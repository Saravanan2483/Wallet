import MembershipPanel from './MembershipPanel';

export default { title: 'Organisms/MembershipPanel', component: MembershipPanel };

export const defaultState = () => <MembershipPanel />;
